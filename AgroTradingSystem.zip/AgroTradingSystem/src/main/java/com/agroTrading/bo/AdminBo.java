package com.agroTrading.bo;

import com.agroTrading.model.AdminCredentials;

public interface AdminBo {
	public String loginAdmin(AdminCredentials admin);
}
