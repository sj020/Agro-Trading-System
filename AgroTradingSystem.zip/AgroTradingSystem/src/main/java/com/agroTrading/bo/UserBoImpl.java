package com.agroTrading.bo;

import org.springframework.beans.factory.annotation.Autowired;

import com.agroTrading.dao.UserDaoImpl;
import com.agroTrading.model.UserCredentials;
import com.agroTrading.model.UserRegistration;

public class UserBoImpl implements UserBo {
	@Autowired
	UserDaoImpl ud;

	public String loginUser(UserCredentials user) {
		return ud.loginUser(user);
	}

	public int registerUser(UserRegistration register) {
		return ud.registerUser(register);
	}
}
