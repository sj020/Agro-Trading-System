package com.agroTrading.bo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.agroTrading.dao.PesticideDaoImpl;
import com.agroTrading.model.Pesticide;

public class PesticideBoImpl implements PesticideBo {
	
	@Autowired
	PesticideDaoImpl pesticideDaoImpl;

	public int save(Pesticide p) {
		return pesticideDaoImpl.save(p);
	}
	
	public int update(Pesticide p) {
		return pesticideDaoImpl.update(p);
	}
	
	public int delete(int id) {
		return pesticideDaoImpl.delete(id);
	}
	
	public Pesticide getPestById(int id) {
		return pesticideDaoImpl.getPestById(id);
	}
	
	public List<Pesticide> getPesticides(){
		return pesticideDaoImpl.getPesticides();
	}
	
	
}
