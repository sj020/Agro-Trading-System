package com.agroTrading.bo;

import com.agroTrading.model.UserCredentials;
import com.agroTrading.model.UserRegistration;

public interface UserBo {

	public String loginUser(UserCredentials user);

	public int registerUser(UserRegistration register);

}
