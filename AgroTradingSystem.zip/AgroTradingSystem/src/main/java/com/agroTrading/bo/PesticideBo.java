package com.agroTrading.bo;

import java.util.List;

import com.agroTrading.model.Pesticide;

public interface PesticideBo {
	
	public int save(Pesticide p);
	
	public int update(Pesticide p);
	
	public int delete(int id);
	
	public Pesticide getPestById(int id);
	
	public List<Pesticide> getPesticides();

}
