package com.agroTrading.bo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.agroTrading.dao.ManureDaoImpl;
import com.agroTrading.dao.PesticideDaoImpl;
import com.agroTrading.model.Manure;
import com.agroTrading.model.Pesticide;

public class ManureBoImpl implements ManureBo {
	@Autowired
	ManureDaoImpl manureDaoImpl;
	
	public int save(Manure m) {
		return manureDaoImpl.save(m);
	}
	
	public int update(Manure m) {
		return manureDaoImpl.update(m);
	}
	
	public int delete(int id) {
		return manureDaoImpl.delete(id);
	}
	
	public Manure getManById(int id) {
		return manureDaoImpl.getManById(id);
	}
	
	public List<Manure> getManure(){
		return manureDaoImpl.getManure();
	}

}
