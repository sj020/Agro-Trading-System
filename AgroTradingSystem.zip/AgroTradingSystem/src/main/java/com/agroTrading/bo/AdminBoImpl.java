package com.agroTrading.bo;

import org.springframework.beans.factory.annotation.Autowired;

import com.agroTrading.dao.AdminDaoImpl;
import com.agroTrading.model.AdminCredentials;

public class AdminBoImpl implements AdminBo {
	@Autowired
	AdminDaoImpl ad;
	
	public String loginAdmin(AdminCredentials admin) {
		return ad.loginAdmin(admin);
	}
}
