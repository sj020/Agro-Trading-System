package com.agroTrading.bo;

import java.util.List;

import com.agroTrading.model.Manure;

public interface ManureBo {
	
	public int save(Manure m);
	
	public int update(Manure m);
	
	public int delete(int id);
	
	public Manure getManById(int id);
	
	public List<Manure> getManure();
}
