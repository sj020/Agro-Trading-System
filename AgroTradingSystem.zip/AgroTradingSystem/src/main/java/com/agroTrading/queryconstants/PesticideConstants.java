package com.agroTrading.queryconstants;

public class PesticideConstants {

	public static final String PESTICIDEADD = "insert into pesticidedata(id,pesticidename,price,quantity,dateofmfg) values(?,?,?,?,?)";
	public static final String PESTICIDEUPDATE = "update pesticidedata set pesticidename=?, price=?,quantity=?,dateofmfg=? where id=?"; 
	public static final String PESTICIDEDELETE = "delete from pesticidedata where id=?";
	public static final String PESTICIDEGETBYID = "select * from pesticidedata where id=?";
	public static final String PESTICIDEFETCH = "select * from pesticidedata";
}
