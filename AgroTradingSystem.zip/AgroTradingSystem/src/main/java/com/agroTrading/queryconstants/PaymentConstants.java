package com.agroTrading.queryconstants;

public class PaymentConstants {
	
	public static final String PAYMENTINSERT = "insert into paymentdetails(sessionid,fname,lname,contact,address,paymentmethod) values(?,?,?,?,?,?)";
	public static final String PAYMENTFETCH = "Select * FROM paymentdetails";

}
