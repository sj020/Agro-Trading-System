package com.agroTrading.queryconstants;

public class ManureConstants {
	
	public static final String MANUREADD = "insert into manuredata(id,manurename,price,quantity,dateofmfg) values(?,?,?,?,?)";
	public static final String MANUREUPDATE = "update manuredata set manurename=?, price=?,quantity=?,dateofmfg=? where id=?"; 
	public static final String MANUREDELETE = "delete from manuredata where id=?";
	public static final String MANUREGETBYID = "select * from manuredata where id=?";
	public static final String MANUREFETCH = "select * from manuredata";

}
