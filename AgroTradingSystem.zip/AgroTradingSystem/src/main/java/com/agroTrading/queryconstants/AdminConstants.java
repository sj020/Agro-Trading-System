package com.agroTrading.queryconstants;

public class AdminConstants {
	public static final String ADMINLOGIN="select first_name from admin where email=? and password=?";
}
