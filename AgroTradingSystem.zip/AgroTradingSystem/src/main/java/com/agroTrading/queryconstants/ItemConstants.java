package com.agroTrading.queryconstants;

public class ItemConstants {
	
	public static final String ITEMINSERT = "insert into itemdata(sessionId,itemid,itemname,itemprice,itemdateofmfg,itemquantity) Values(?,?,?,?,?,?)";
	public static final String ITEMUPDATE = "update pesticidedata set quantity=? where id=?";
	public static final String ITEMCART = "Select itemid,itemname,itemprice,itemdateofmfg,SUM(itemquantity) AS itemquantity FROM itemdata WHERE sessionid=? GROUP BY itemid";
}
