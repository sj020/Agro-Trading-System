package com.agroTrading.model;

public class Pesticide {
	private int id;
	private String pesticideName;
	private int price;
	private String dateOfMfg;
	private int quantity;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getPesticideName() {
		return pesticideName;
	}
	public void setPesticideName(String pesticideName) {
		this.pesticideName = pesticideName;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public String getDateOfMfg() {
		return dateOfMfg;
	}
	public void setDateOfMfg(String dateOfMfg) {
		this.dateOfMfg = dateOfMfg;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	}
