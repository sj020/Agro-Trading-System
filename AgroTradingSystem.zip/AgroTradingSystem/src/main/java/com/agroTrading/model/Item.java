package com.agroTrading.model;

public class Item {
	
	private String sessionId;
	private int itemId;
	private String itemName;
	private int itemPrice;
	private String itemDateOfMfg;
	private int itemQuantity;
	
	public String getSessionId() {
		return sessionId;
	}
	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}
	public int getItemId() {
		return itemId;
	}
	public void setItemId(int itemId) {
		this.itemId = itemId;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public int getItemPrice() {
		return itemPrice;
	}
	public void setItemPrice(int i) {
		this.itemPrice = i;
	}
	public String getItemDateOfMfg() {
		return itemDateOfMfg;
	}
	public void setItemDateOfMfg(String itemDateOfMfg) {
		this.itemDateOfMfg = itemDateOfMfg;
	}
	public int getItemQuantity() {
		return itemQuantity;
	}
	public void setItemQuantity(int itemQuantity) {
		this.itemQuantity = itemQuantity;
	}
}
