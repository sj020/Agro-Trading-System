package com.agroTrading.model;

public class UserRegistration {

	private String firstName;
	private String lastName;
	private String contact;
	private String email;
	private String password;
	private String gender;

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("User Registration details  ").append("firstname = ").append(firstName);
		builder.append(", lastname = ").append(lastName);
		builder.append(", contact number= ").append(contact);
		builder.append(", email= ").append(email);
		builder.append(", password= ").append(password);
		builder.append(", gender= ").append(gender);

		return builder.toString();
	}

}
