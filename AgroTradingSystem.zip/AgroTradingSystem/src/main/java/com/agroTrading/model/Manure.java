package com.agroTrading.model;

public class Manure {
	private int id;
	private String manureName;
	private int price;
	private String dateOfMfg;
	private int quantity;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getManureName() {
		return manureName;
	}
	public void setManureName(String manureName) {
		this.manureName = manureName;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public String getDateOfMfg() {
		return dateOfMfg;
	}
	public void setDateOfMfg(String dateOfMfg) {
		this.dateOfMfg = dateOfMfg;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

}
