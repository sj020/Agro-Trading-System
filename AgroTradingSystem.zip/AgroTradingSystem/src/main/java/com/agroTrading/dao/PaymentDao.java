package com.agroTrading.dao;

import java.util.List;

import com.agroTrading.model.Payment;

public interface PaymentDao {
	
	public int save(Payment p);
	public List<Payment> getOrders();
	
		
}
