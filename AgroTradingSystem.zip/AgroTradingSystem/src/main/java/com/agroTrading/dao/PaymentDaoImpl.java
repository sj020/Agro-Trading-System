package com.agroTrading.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.agroTrading.model.Item;
import com.agroTrading.model.Payment;
import com.agroTrading.queryconstants.PaymentConstants;

public class PaymentDaoImpl {
	
	private JdbcTemplate jdbcTemplate;

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
	
public int save(Payment p) {
		
		String sql = PaymentConstants.PAYMENTINSERT;
		try {
			int counter = jdbcTemplate.update(sql,new Object[] {p.getSessionId(),p.getFname(), p.getLname(),
					p.getContact(),p.getAddress(), p.getPayment() });
			return counter;

		}
		catch(Exception e) {
			System.out.println(e.getMessage());
			return 0;
	}
}

public List<Payment> getOrders() {
	 String sql = PaymentConstants.PAYMENTFETCH;    
		List<Payment> list =  jdbcTemplate.query(sql,new RowMapper<Payment>() {

			public Payment mapRow(ResultSet rs, int rowNum) throws SQLException {
				Payment pest = new Payment();
				pest.setSessionId(rs.getString("sessionId"));
				pest.setFname(rs.getString("fname"));
				pest.setLname(rs.getString("lname"));
				pest.setContact(rs.getString("contact"));
				pest.setAddress(rs.getString("address"));
				pest.setPayment(rs.getString("paymentmethod"));
				return pest;
			}
		});
		return list;
}
}
