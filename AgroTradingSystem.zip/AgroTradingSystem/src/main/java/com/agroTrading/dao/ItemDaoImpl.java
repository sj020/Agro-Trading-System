package com.agroTrading.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.agroTrading.model.Item;
import com.agroTrading.model.Manure;
import com.agroTrading.model.Pesticide;
import com.agroTrading.queryconstants.ItemConstants;
import com.agroTrading.queryconstants.PesticideConstants;

public class ItemDaoImpl implements ItemDao {
	
	private JdbcTemplate jdbcTemplate;

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
	
	public int savepesticide(Item it,Pesticide p) {
		
		String sql1 = ItemConstants.ITEMINSERT;
		String sql2 = ItemConstants.ITEMUPDATE;
		int finalQuantity = p.getQuantity()-it.getItemQuantity();
		try {
			int counter1 = jdbcTemplate.update(sql1,new Object[] {it.getSessionId() ,it.getItemId(), it.getItemName(),
					it.getItemPrice(), it.getItemDateOfMfg(),it.getItemQuantity() });
			int counter2 = jdbcTemplate.update(sql2,new Object[] {finalQuantity,it.getItemId()});
			return counter1+counter2;

		}
		catch(Exception e) {
			return 0;
		}
	}
	
	public int savemanure(Item it,Manure m) {
		
		String sql1 = ItemConstants.ITEMINSERT;
		String sql2 = ItemConstants.ITEMUPDATE;
		int finalQuantity = m.getQuantity()-it.getItemQuantity();
		try {
			int counter1 = jdbcTemplate.update(sql1,new Object[] {it.getSessionId() ,it.getItemId(), it.getItemName(),
					it.getItemPrice(), it.getItemDateOfMfg(),it.getItemQuantity() });
			int counter2 = jdbcTemplate.update(sql2,new Object[] {finalQuantity,it.getItemId()});
			return counter1+counter2;

		}
		catch(Exception e) {
			return 0;
		}
	}
	
	public List<Item> getCart(String id){
		 String sql = ItemConstants.ITEMCART;    
			List<Item> list =  jdbcTemplate.query(sql,new Object[]{id} ,new RowMapper<Item>() {

				public Item mapRow(ResultSet rs, int rowNum) throws SQLException {
					Item pest = new Item();
					
					pest.setItemId(rs.getInt("itemid"));
					pest.setItemName(rs.getString("itemname"));
					pest.setItemPrice(rs.getInt("itemprice"));
					pest.setItemDateOfMfg(rs.getString("itemdateofmfg"));
					pest.setItemQuantity(rs.getInt("itemquantity"));
					return pest;
				}
			});
			return list;
	}
	
	public int delete(int id,String sessionId) {
		String sql = "delete from itemdata where itemid=? && sessionId=?";
		return jdbcTemplate.update(sql,new Object[]{id,sessionId});
	}

	public List<Item> getOrders() {
		 String sql = "Select sessionid,itemid,itemname,itemprice,itemdateofmfg,SUM(itemquantity) AS itemquantity FROM itemdata WHERE isbought=TRUE Group By itemname";
		 
			List<Item> list =  jdbcTemplate.query(sql,new RowMapper<Item>() {

				public Item mapRow(ResultSet rs, int rowNum) throws SQLException {
					Item pest = new Item();
					pest.setSessionId(rs.getString("sessionId"));
					pest.setItemId(rs.getInt("itemid"));
					pest.setItemName(rs.getString("itemname"));
					pest.setItemPrice(rs.getInt("itemprice"));
					pest.setItemDateOfMfg(rs.getString("itemdateofmfg"));
					pest.setItemQuantity(rs.getInt("itemquantity"));
					return pest;
				}
			});
			return list;
	}
	public int confirmPayment(String sessionId) {
		String sql = "update itemdata set isbought=true where sessionid = ?";
		return jdbcTemplate.update(sql,new Object[] {sessionId});
		
	}
}
