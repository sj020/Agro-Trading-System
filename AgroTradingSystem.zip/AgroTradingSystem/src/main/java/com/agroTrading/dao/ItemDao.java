package com.agroTrading.dao;

import java.util.List;

import com.agroTrading.model.Item;
import com.agroTrading.model.Manure;
import com.agroTrading.model.Pesticide;

public interface ItemDao {
	public int savepesticide(Item it,Pesticide p);
	public int savemanure(Item it,Manure m);
	public List<Item> getCart(String id);
	public int delete(int id,String sessionId);
	public List<Item> getOrders();
	public int confirmPayment(String sessionId);

}
