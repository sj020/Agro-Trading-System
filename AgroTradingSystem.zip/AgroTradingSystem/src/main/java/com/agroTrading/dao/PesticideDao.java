package com.agroTrading.dao;

import java.util.List;

import com.agroTrading.model.Pesticide;

public interface PesticideDao {
	
	public int save(Pesticide p);
	
	public int update(Pesticide m);
	
	public int delete(int id);
	
	public Pesticide getPestById(int id);
	
	public List<Pesticide> getPesticides();
	

}
