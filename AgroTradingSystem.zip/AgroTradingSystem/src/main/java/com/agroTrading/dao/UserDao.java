package com.agroTrading.dao;


import com.agroTrading.model.UserCredentials;
import com.agroTrading.model.UserRegistration;

public interface UserDao  {

	public int registerUser(UserRegistration register);
	public String loginUser(UserCredentials user);

}
