package com.agroTrading.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.agroTrading.model.Manure;
import com.agroTrading.queryconstants.ManureConstants;

public class ManureDaoImpl implements ManureDao {
	private JdbcTemplate jdbcTemplate;

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
	
	public int save(Manure m) {
		
		String sql = ManureConstants.MANUREADD;
		try {
			int counter = jdbcTemplate.update(sql,new Object[] { m.getId(), m.getManureName(),
					m.getPrice(),m.getQuantity(), m.getDateOfMfg() });
			return counter;

		}
		catch(Exception e) {
			return 0;
	}
}
	
	public int update(Manure m) {
		String sql = ManureConstants.MANUREUPDATE;
		return jdbcTemplate.update(sql,new Object[] {m.getManureName(),m.getPrice(),m.getQuantity(),m.getDateOfMfg(),m.getId()});
	}
	
	public int delete(int id) {
		String sql = ManureConstants.MANUREDELETE;
		return jdbcTemplate.update(sql,new Object[]{id});
	}
	
	public Manure getManById(int id){    
	    String sql=ManureConstants.MANUREGETBYID;    
	    return jdbcTemplate.queryForObject(sql, new Object[]{id},new BeanPropertyRowMapper<Manure>(Manure.class));    
	}    
	
	public List<Manure> getManure(){    

		List<Manure> list =  jdbcTemplate.query(ManureConstants.MANUREFETCH, new RowMapper<Manure>() {

			public Manure mapRow(ResultSet rs, int rowNum) throws SQLException {
				Manure man = new Manure();
				
				man.setId(rs.getInt("id"));
				man.setManureName(rs.getString("manurename"));
				man.setPrice(rs.getInt("price"));
				man.setQuantity(rs.getInt("quantity"));
				man.setDateOfMfg(rs.getString("dateofmfg"));
				return man;
			}
		});
		return list;

	    
	}

}
