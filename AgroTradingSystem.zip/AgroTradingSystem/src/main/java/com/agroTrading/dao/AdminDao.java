package com.agroTrading.dao;

import com.agroTrading.model.AdminCredentials;

public interface AdminDao  {
	public String loginAdmin(AdminCredentials admin);
}