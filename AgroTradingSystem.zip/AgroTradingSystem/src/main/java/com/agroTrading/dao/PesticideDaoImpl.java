package com.agroTrading.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.agroTrading.model.Pesticide;
import com.agroTrading.queryconstants.PesticideConstants;

public class PesticideDaoImpl implements PesticideDao {
	
	private JdbcTemplate jdbcTemplate;

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
	
	public int save(Pesticide p) {
		
		String sql = PesticideConstants.PESTICIDEADD;
		try {
			int counter = jdbcTemplate.update(sql,new Object[] { p.getId(), p.getPesticideName(),
					p.getPrice(),p.getQuantity(), p.getDateOfMfg() });
			return counter;

		}
		catch(Exception e) {
			System.out.println(e.getMessage());
			return 0;
	}
}
	
	public int update(Pesticide p) {
		String sql = "update pesticidedata set pesticidename='"+p.getPesticideName()+"', price="+p.getPrice()+",quantity='"+p.getQuantity()+"' where id="+p.getId()+"";
		return jdbcTemplate.update(sql);
	}
	
	public int delete(int id) {
		String sql = PesticideConstants.PESTICIDEDELETE;
		return jdbcTemplate.update(sql,new Object[]{id});
	}
	
	public Pesticide getPestById(int id){    
	    String sql=PesticideConstants.PESTICIDEGETBYID;    
	    return jdbcTemplate.queryForObject(sql, new Object[]{id},new BeanPropertyRowMapper<Pesticide>(Pesticide.class));    
	}    
	
	public List<Pesticide> getPesticides(){    

		List<Pesticide> list =  jdbcTemplate.query(PesticideConstants.PESTICIDEFETCH, new RowMapper<Pesticide>() {

			public Pesticide mapRow(ResultSet rs, int rowNum) throws SQLException {
				Pesticide pest = new Pesticide();
				
				pest.setId(rs.getInt("id"));
				pest.setPesticideName(rs.getString("pesticidename"));
				pest.setPrice(rs.getInt("price"));
				pest.setQuantity(rs.getInt("quantity"));
				pest.setDateOfMfg(rs.getString("dateofmfg"));
				return pest;
			}
		});
		return list;
	}
}

