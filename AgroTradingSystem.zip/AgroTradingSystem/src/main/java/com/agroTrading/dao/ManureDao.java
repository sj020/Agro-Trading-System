package com.agroTrading.dao;

import java.util.List;

import com.agroTrading.model.Manure;

public interface ManureDao {
	
	public int save(Manure m);
	
	public int update(Manure m);
	
	public int delete(int id);
	
	public Manure getManById(int id);
	
	public List<Manure> getManure();
	
}
