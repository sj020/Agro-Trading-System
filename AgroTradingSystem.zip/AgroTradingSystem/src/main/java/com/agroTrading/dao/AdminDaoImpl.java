package com.agroTrading.dao;

import org.springframework.jdbc.core.JdbcTemplate;

import com.agroTrading.model.AdminCredentials;
import com.agroTrading.queryconstants.AdminConstants;

public class AdminDaoImpl implements AdminDao {
	
	private JdbcTemplate jdbcTemplate;

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
	
	public String loginAdmin(AdminCredentials admin) {
		String sql = AdminConstants.ADMINLOGIN;

		try {
			String name = jdbcTemplate.queryForObject(sql,new Object[] { admin.getEmail(), admin.getPassword()}, String.class);
			return name;

		} catch (Exception e) {
			return null;
		}
	}

}
