package com.agroTrading.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.agroTrading.bo.UserBoImpl;
import com.agroTrading.model.UserCredentials;

@Controller
public class UserLoginController {

	@Autowired
	private UserBoImpl userBoImpl;

	@RequestMapping(value = "/userlogin", method = RequestMethod.POST)
	public ModelAndView userLogin(@RequestParam("emailid") String email, @RequestParam("pw") String password,HttpSession session) {

		ModelAndView mv = new ModelAndView();
		UserCredentials user = new UserCredentials();
		user.setEmail(email);
		user.setPassword(password);
		String name = userBoImpl.loginUser(user);

		if (name != null) {
			mv.addObject("msg", "Welcome " + name + ", You have successfully logged in.");
			session.setAttribute("email", email);
			mv.setViewName("welcomeuser");

		} else {
			mv.addObject("msg", "Invalid email id or password.");
			mv.setViewName("userLogin");
		}
		return mv;

	}
	
	@RequestMapping(value = "/logout", method = RequestMethod.GET)
	public String logout(HttpSession session) {
		session.removeAttribute("email");
		return "redirect:/userlogin";
	}

}
