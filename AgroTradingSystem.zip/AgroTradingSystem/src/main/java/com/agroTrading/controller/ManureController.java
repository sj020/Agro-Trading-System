package com.agroTrading.controller;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.agroTrading.bo.ManureBoImpl;
import com.agroTrading.model.Manure;
import com.agroTrading.model.Pesticide;

@Controller
public class ManureController {
	@Autowired
	ManureBoImpl manureBoImpl;
	
	/*
	 * @RequestMapping("/addpesticide") public String showform(Model m) {
	 * m.addAttribute("command", new Pesticide()); return "addpesticide"; }
	 */
	
	@RequestMapping(value="/manuresave",method=RequestMethod.POST)
	public ModelAndView save(@RequestParam("id") int id,
			@RequestParam("manurename") String manureName, @RequestParam("price") int price,@RequestParam("quantity") int quantity,
			@RequestParam("dateofmfg") String dateofmfg) {
		
		ModelAndView mv = new ModelAndView();
		Manure man = new Manure();
		man.setId(id);
		man.setManureName(manureName);
		man.setPrice(price);
		man.setQuantity(quantity);
		man.setDateOfMfg(dateofmfg);
		
		int counter = manureBoImpl.save(man);
		
		if(counter>0) {
			mv.addObject("msg","Manure Detail Added Sucessfully");
		}
		else {
			mv.addObject("msg","Manure could not be Added");
			
		}
		mv.setViewName("addmanure");
		
		return mv;
	}
	
	@RequestMapping("/listofmanure")
	public ModelAndView viewpesticide(ModelAndView mv){
        List<Manure> manureList=manureBoImpl.getManure();    
        mv.addObject("list",manureList);  
        mv.setViewName("listofmanure");
        return mv;
	}
	
	@RequestMapping(value="/editmanure/{id}")
	public String edit(@PathVariable int id, Model m) {
	Manure man=manureBoImpl.getManById(id);    
        m.addAttribute("man",man);  
       return "editmanure";    
	}
	
    @RequestMapping(value="/editsavemanure",method= RequestMethod.POST)    
    public String editsave(@ModelAttribute("man") Manure man){
   	manureBoImpl.update(man);
	return "redirect:/listofmanure";        
    }  
	
	@RequestMapping(value="/deletemanure/{id}",method=RequestMethod.GET)
	public ModelAndView delete(@PathVariable int id) {
		manureBoImpl.delete(id);
		ModelAndView mv = new ModelAndView("redirect:/listofmanure");
		return mv;
	}
}
