package com.agroTrading.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.agroTrading.bo.UserBoImpl;
import com.agroTrading.model.UserRegistration;

@Controller
public class UserRegistrataionController {
	@Autowired
	private UserBoImpl userBoImpl;

	@RequestMapping(value = "/userregister", method = RequestMethod.POST)
	public ModelAndView userRegistration(@RequestParam("firstname") String firstName,
			@RequestParam("lastname") String lastName, @RequestParam("contactnumber") String contact,
			@RequestParam("emailid") String email, @RequestParam("pw") String password,
			@RequestParam("gender") String gender) {
	
		
		ModelAndView mv = new ModelAndView();
		UserRegistration user = new UserRegistration();
		user.setFirstName(firstName);
		user.setLastName(lastName);
		user.setContact(contact);
		user.setEmail(email);
		user.setPassword(password);
		user.setGender(gender);

		int counter = userBoImpl.registerUser(user);

		if (counter > 0) {
			mv.addObject("msg", "User registration successful.");
		} else {
			mv.addObject("msg", "User already exist.");
		}

		mv.setViewName("userRegistration");

		return mv;

	}

}
