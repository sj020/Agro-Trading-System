package com.agroTrading.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.agroTrading.bo.PesticideBoImpl;
import com.agroTrading.model.Pesticide;

@Controller
public class PesticideController {
	@Autowired
	PesticideBoImpl pesticideBoImpl;
	
	/*
	 * @RequestMapping("/addpesticide") public String showform(Model m) {
	 * m.addAttribute("command", new Pesticide()); return "addpesticide"; }
	 */
	
	@RequestMapping(value="/pesticidesave",method=RequestMethod.POST)
	public ModelAndView save(@RequestParam("id") int id,
			@RequestParam("pesticidename") String pesticideName, @RequestParam("price") int price,@RequestParam("quantity") int quantity,
			@RequestParam("dateofmfg") String dateofmfg) {
		
		ModelAndView mv = new ModelAndView();
		Pesticide pest = new Pesticide();
		pest.setId(id);
		pest.setPesticideName(pesticideName);
		pest.setPrice(price);
		pest.setQuantity(quantity);
		pest.setDateOfMfg(dateofmfg);
		
		int counter = pesticideBoImpl.save(pest);
		
		if(counter>0) {
			mv.addObject("msg","Pesticide Detail Added Sucessfully");
		}
		else {
			mv.addObject("msg","Pesticide could not be Added");
			
		}
		mv.setViewName("addpesticide");
		
		return mv;
	}
	
	@RequestMapping("/listofpesticide")
	public ModelAndView viewpesticide(ModelAndView mv) {
        List<Pesticide> pesticideList= pesticideBoImpl.getPesticides();    
        mv.addObject("list",pesticideList);  
        mv.setViewName("listofpesticide");
        return mv;
	}
	
	@RequestMapping(value="/editpesticide/{id}")
	public String edit(@PathVariable int id, Model m) {
	Pesticide pest=pesticideBoImpl.getPestById(id);    
        m.addAttribute("pest",pest);  
       return "editpesticide";    
	}
	
    @RequestMapping(value="/editsavepesticide",method= RequestMethod.POST)    
    public String editsave(@ModelAttribute("pest") Pesticide pest){
   	pesticideBoImpl.update(pest);
	return "redirect:/listofpesticide";        
    }   
    
	@RequestMapping(value="/deletepesticide/{id}",method=RequestMethod.GET)
	public ModelAndView delete(@PathVariable int id) {
		pesticideBoImpl.delete(id);
		ModelAndView mv = new ModelAndView("redirect:/listofpesticide");
		return mv;
	}

}
