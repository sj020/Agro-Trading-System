package com.agroTrading.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.agroTrading.bo.ManureBoImpl;
import com.agroTrading.bo.PesticideBoImpl;
import com.agroTrading.dao.ItemDaoImpl;
import com.agroTrading.model.Item;
import com.agroTrading.model.Manure;
import com.agroTrading.model.Pesticide;

@Controller
public class OrderController {
	
	@Autowired
	PesticideBoImpl pesticideBoImpl;
	@Autowired
	ManureBoImpl manureBoImpl;
	@Autowired
	ItemDaoImpl itemDaoImpl;

	@RequestMapping("/buypesticides")
	public ModelAndView viewpesticide(@RequestParam(value = "msg", required = false) String msg,ModelAndView mv) {
        List<Pesticide> pesticideList= pesticideBoImpl.getPesticides();    
        mv.addObject("list",pesticideList);  
        mv.addObject("msg", msg);
        mv.setViewName("buypesticides");
        return mv;
	}

	@RequestMapping("/buymanure")
	public ModelAndView viewmanure(ModelAndView mv){
        List<Manure> manureList=manureBoImpl.getManure();    
        mv.addObject("list",manureList);  
        mv.setViewName("buymanure");
        return mv;
	}
	
	@RequestMapping(value = "/buypesticide",method=RequestMethod.POST)
	public ModelAndView buypesticides(@RequestParam("id") int id,@RequestParam("quantity") int quantity,HttpServletRequest request) {
		
		String sessionId = (String) request.getSession().getAttribute("email");
		Pesticide pest = pesticideBoImpl.getPestById(id);
		Item it = new Item();
		ModelAndView mv = new ModelAndView();
		it.setSessionId(sessionId);
		it.setItemId(pest.getId());
		it.setItemName(pest.getPesticideName());
		it.setItemPrice(pest.getPrice());
		it.setItemDateOfMfg(pest.getDateOfMfg());
		it.setItemQuantity(quantity);
		int counter = itemDaoImpl.savepesticide(it,pest);
		if(counter>1) {
			mv.addObject("msg","Added to Cart Sucessfully");
		}
		else {
			mv.addObject("msg","Could not be Added to Cart");	
		}
		mv.setViewName("redirect:/buypesticides");
        return mv;
        
	}
	
	@RequestMapping(value = "/buymanure",method=RequestMethod.POST)
	public ModelAndView buymanure(@RequestParam("id") int id,@RequestParam("quantity") int quantity,HttpServletRequest request) {
		
		String sessionId = (String) request.getSession().getAttribute("email");
		Manure man = manureBoImpl.getManById(id);
		Item it = new Item();
		ModelAndView mv = new ModelAndView();
		it.setSessionId(sessionId);
		it.setItemId(man.getId());
		it.setItemName(man.getManureName());
		it.setItemPrice(man.getPrice());
		it.setItemDateOfMfg(man.getDateOfMfg());
		it.setItemQuantity(quantity);
		int counter = itemDaoImpl.savemanure(it,man);
		if(counter>1) {
			mv.addObject("msg","Added to Cart Sucessfully");
		}
		else {
			mv.addObject("msg","Could not be Added to Cart");	
		}
		mv.setViewName("redirect:/buymanure");
        return mv;
        
	}
	
	@RequestMapping("/cart")
	public ModelAndView viewcart(HttpServletRequest request) {
		String sessionId = (String) request.getSession().getAttribute("email");
		List<Item> list = itemDaoImpl.getCart(sessionId);
		ModelAndView mv = new ModelAndView();
        mv.addObject("list",list);  
		mv.setViewName("cart");
		return mv;

	}
	
	@RequestMapping(value="/remove/{itemId}",method=RequestMethod.GET)
	public ModelAndView delete(@PathVariable("itemId") int id,HttpServletRequest request) {
		String sessionId = (String) request.getSession().getAttribute("email");
		itemDaoImpl.delete(id,sessionId);
		ModelAndView mv = new ModelAndView("redirect:/cart");
		return mv;
	}
	
	@RequestMapping("/orderslist")
	public ModelAndView vieworders(ModelAndView mv) {
        List<Item> orderList= itemDaoImpl.getOrders();
        mv.addObject("list",orderList);  
        mv.setViewName("orderslist");
        return mv;
	}

}
