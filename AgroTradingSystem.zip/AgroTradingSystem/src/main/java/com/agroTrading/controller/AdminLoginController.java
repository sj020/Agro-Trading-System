package com.agroTrading.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.agroTrading.bo.AdminBoImpl;
import com.agroTrading.model.AdminCredentials;

@Controller
public class AdminLoginController {

	@Autowired
	private AdminBoImpl adminBoImpl;

	@RequestMapping(value = "/adminlogin", method = RequestMethod.POST)
	public ModelAndView userLogin(@RequestParam("email") String email, @RequestParam("password") String password) {

		ModelAndView mv = new ModelAndView();
		AdminCredentials admin = new AdminCredentials();
		admin.setEmail(email);
		admin.setPassword(password);
		String name = adminBoImpl.loginAdmin(admin);

		if (name != null) {
			mv.addObject("msg", "Welcome " + name + ", You have successfully logged in.");
			mv.setViewName("welcomeadmin");

		} else {
			mv.addObject("msg", "Invalid email id or password.");
			mv.setViewName("adminLogin");
		}

		return mv;

	}

}
