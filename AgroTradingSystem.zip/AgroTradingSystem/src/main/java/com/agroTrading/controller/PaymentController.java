package com.agroTrading.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.agroTrading.dao.ItemDaoImpl;
import com.agroTrading.dao.PaymentDaoImpl;
import com.agroTrading.model.Item;
import com.agroTrading.model.Payment;

@Controller
public class PaymentController {
	
	@Autowired
	ItemDaoImpl itemDaoImpl;
	
	@Autowired
	PaymentDaoImpl paymentDaoImpl;
	
	@RequestMapping(value = "/paymentdet", method = RequestMethod.POST)
	public String paymentadd(@RequestParam("firstname")String fname,@RequestParam("lastname")String lname,
			@RequestParam("contactnumber")String contactno,@RequestParam("address")String address,@RequestParam("paymentmethod1")String payment,
			HttpServletRequest request){
		String sessionId = (String) request.getSession().getAttribute("email");
		Payment pay = new Payment();
		pay.setSessionId(sessionId);
		pay.setFname(fname);
		pay.setLname(lname);
		pay.setContact(contactno);
		pay.setAddress(address);
		pay.setPayment(payment);
		itemDaoImpl.confirmPayment(sessionId);
		paymentDaoImpl.save(pay);
		return "redirect:/final.jsp";	
	}
	
	
	@RequestMapping("/paymentdetails")
	public ModelAndView paymentview(ModelAndView mv) {
        List<Payment> paymentList= paymentDaoImpl.getOrders();    
        mv.addObject("list",paymentList);  
        mv.setViewName("paymentdetails");
        return mv;
	}

}
