create database Agro_Trading;
use Agro_Trading;
create table admin
(
first_name varchar(30) not null,
    last_name varchar(30) not null,
    contact_number varchar(20) not null,
    email varchar(30) primary key,
    password varchar(30)not null
);
Insert into admin(first_name,last_name,contact_number,email,password)
values("Sidhant","Jain","96543993773","sidhant21@gmail.com","Sidhant@21")

create table user(
first_name varchar(30) not null,
    last_name varchar(30) not null,
    contact_number varchar(20) not null,
    email varchar(30) primary key,
    password varchar(30) not null,
    gender varchar(20) not null
);

create table pesticidedata(
	id int not null primary key,
	pesticidename VARCHAR(30),
    price int not null,
    quantity int not null,
    dateofmfg varchar(255) not null
);

create table manuredata(
	id int not null primary key ,
	manurename VARCHAR(30),
    price int not null,
    quantity int not null,
    dateofmfg varchar(255) not null
);

create table itemdata(
	sessionid varchar(255) not null,
	itemid int not null,
	itemname VARCHAR(30),
    itemprice int not null,
    itemdateofmfg date not null,
    itemquantity int not null,
    isbought boolean default false
);
create table paymentdetails(
	sessionid varchar(255) not null,
    fname varchar(30) not null,
    lname varchar(30) not null,
    contact varchar(40) not null,
    address varchar(255) not null,
    paymentmethod varchar(100) not null
);
select * from admin;
select * from user;
select * from pesticidedata;
select * from manuredata;
select * from itemdata;